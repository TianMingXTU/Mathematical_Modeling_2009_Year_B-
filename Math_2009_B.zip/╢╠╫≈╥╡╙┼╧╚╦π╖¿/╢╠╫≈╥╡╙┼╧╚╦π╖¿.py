import pandas as pd
from matplotlib import pyplot as plt


plt.rcParams['font.sans-serif'] = ['SimHei']  # 或者使用 ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False
# 读取Excel数据
data = pd.read_excel('可用完整数据.xlsx')

# 初始化模拟环境
current_time = min(data['门诊时间'])
max_beds = 79
beds_available = max_beds
patient_queue = []
scheduled_operations = []

# 用于存储每天的数据，用于后续可视化
daily_metrics = []

# 用于记录每次迭代的等待住院病人数量
queue_history = []

# 模拟主循环
while current_time <= max(data['出院时间']):
    # 处理病人到达事件
    patients_arriving = data[data['门诊时间'] == current_time]

    # 处理急症外伤
    emergency_patients = patients_arriving[patients_arriving['类型'] == '急症外伤']
    for _, patient in emergency_patients.iterrows():
        if beds_available > 0:
            beds_available -= 1
            scheduled_operations.append((patient['序号'], '急症外伤', current_time))

    # 处理白内障手术
    cataract_patients = patients_arriving[patients_arriving['类型'] == '白内障']
    for _, patient in cataract_patients.iterrows():
        if beds_available > 0:
            beds_available -= 1
            scheduled_operations.append((patient['序号'], '白内障', current_time))

    # 处理其他眼科疾病
    other_patients = patients_arriving[patients_arriving['类型'].isin(['视网膜疾病', '青光眼'])]
    for _, patient in other_patients.iterrows():
        if beds_available > 0:
            beds_available -= 1
            scheduled_operations.append((patient['序号'], patient['类型'], current_time))

    # 处理出院事件
    patients_leaving = data[data['出院时间'] == current_time]
    for _, patient in patients_leaving.iterrows():
        beds_available = min(max_beds, beds_available + 1)
        scheduled_operations = [op for op in scheduled_operations if op[0] != patient['序号']]

    # 步骤4：预测第二天的病人安排
    if current_time.day_name() in ['Saturday', 'Sunday']:
        # 周六、周日不安排手术，只安排住院
        next_day_discharges = (data['出院时间'] == current_time + pd.Timedelta(days=1)).sum()

        for _ in range(next_day_discharges):
            if patient_queue:
                # 实现短作业优先算法来选择患者
                patient_id = patient_queue[0]
                patient_type = data.loc[patient_queue[0], '类型']  # 获取队列中第一个患者的类型
                patients_for_admission = [op for op in scheduled_operations if op[1] == patient_type]
                if patients_for_admission:
                    patient_to_admit = min(patients_for_admission, key=lambda x: data.loc[x[0], '病床占用时间'])  # 根据病床占用时间选择最短作业
                    if patient_id in patient_queue:
                        patient_queue.remove(patient_id)
                    scheduled_operations.remove(patient_to_admit)
                    scheduled_operations.append((patient_to_admit[0], '住院', current_time + pd.Timedelta(days=1)))
                    beds_available = max(0, beds_available - 1)
    else:
        # 工作日安排手术和住院
        estimated_beds_needed = max_beds - beds_available

        for patient_type in ['白内障', '视网膜疾病', '青光眼']:
            patients_for_admission = [op for op in scheduled_operations if op[1] == patient_type]
            patients_for_admission = patients_for_admission[:estimated_beds_needed]
            for patient_op in patients_for_admission:
                patient_queue.append(patient_op[0])
                scheduled_operations.remove(patient_op)

        next_day_discharges = (data['出院时间'] == current_time + pd.Timedelta(days=1)).sum()

        for _ in range(next_day_discharges):
            if patient_queue:
                patient_id = patient_queue[0]
                patient_type = data.loc[patient_queue[0], '类型']
                patients_for_admission = [op for op in scheduled_operations if op[1] == patient_type]
                if patients_for_admission:
                    patient_to_admit = min(patients_for_admission, key=lambda x: data.loc[x[0], '病床占用时间'])
                    if patient_id in patient_queue:
                        patient_queue.remove(patient_id)
                    scheduled_operations.remove(patient_to_admit)
                    if patient_type == '急症外伤':
                        scheduled_operations.append((patient_to_admit[0], '急症外伤', current_time + pd.Timedelta(days=1)))
                    elif patient_type == '白内障':
                        if current_time.day_name() == 'Monday':
                            scheduled_operations.append((patient_to_admit[0], '白内障', current_time + pd.Timedelta(days=2)))
                        else:
                            scheduled_operations.append((patient_to_admit[0], '白内障', current_time + pd.Timedelta(days=1)))
                    else:
                        days_until_surgery = 2 if current_time.day_name() in ['Monday', 'Wednesday'] else 1
                        scheduled_operations.append((patient_to_admit[0], patient_type, current_time + pd.Timedelta(days=days_until_surgery)))
                    beds_available = max(0, beds_available - 1)

        # 步骤5：根据已知的第二天拟出院病人数，安排住院病人
        next_day_discharges = (data['出院时间'] == current_time + pd.Timedelta(days=1)).sum()  # 根据数据或模型预测的第二天拟出院病人数

        for _ in range(next_day_discharges):
            if patient_queue:  # 确保队列中有病人等待住院
                patient_to_admit = patient_queue.pop(0)
                # 根据病人类型安排手术时间
                patient_type = data.loc[patient_to_admit, '类型']
                if patient_type == '急症外伤':
                    scheduled_operations.append((patient_to_admit, '急症外伤', current_time + pd.Timedelta(days=1)))
                elif patient_type == '白内障':
                    if current_time.day_name() == 'Monday':
                        scheduled_operations.append((patient_to_admit, '白内障', current_time + pd.Timedelta(days=2)))
                    else:
                        scheduled_operations.append((patient_to_admit, '白内障', current_time + pd.Timedelta(days=1)))
                else:
                    # 其他眼科疾病
                    days_until_surgery = 2 if current_time.day_name() in ['Monday', 'Wednesday'] else 1
                    scheduled_operations.append(
                        (patient_to_admit, patient_type, current_time + pd.Timedelta(days=days_until_surgery)))
                beds_available = max(0, beds_available - 1)

    # 保存每天的指标数据，用于可视化
    daily_metrics.append({
        '时间': current_time,
        '床位利用率': (max_beds - beds_available) / max_beds,
        '等待住院人数': len(patient_queue),
        '已安排手术数': len(scheduled_operations),
        '其他评价指标': 0.0  # 根据实际情况填写
    })

    # 记录当前迭代的队列长度
    queue_history.append(len(scheduled_operations))

    # 更新模拟时间
    current_time += pd.Timedelta(days=1)

# 将每天的指标数据转换为DataFrame
daily_metrics_df = pd.DataFrame(daily_metrics)

# 可视化床位利用率和其他指标随时间变化的趋势
plt.figure(figsize=(10, 6))
plt.plot(daily_metrics_df['时间'], daily_metrics_df['床位利用率'], label='床位利用率')
plt.xlabel('时间')
plt.ylabel('病床利用率')
plt.title('病床利用率随时间变化趋势')
plt.legend()
plt.grid()
plt.savefig('病床利用率随时间变化趋势.png')
plt.show()

# 可视化patient_queue随时间变化的趋势
plt.figure(figsize=(10, 6))
plt.plot(daily_metrics_df['时间'],queue_history)
plt.xlabel('时间')
plt.ylabel('需要安排住院病人数量')
plt.title('需要安排住院病人数量随时间变化的趋势')
plt.grid()
# 保存可视化图表
plt.savefig('需要安排住院病人数量随时间变化的趋势.png')
plt.show()
