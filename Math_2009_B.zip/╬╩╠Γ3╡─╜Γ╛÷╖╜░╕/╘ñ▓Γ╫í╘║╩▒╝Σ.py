import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from datetime import datetime

# 读取Excel数据
data = pd.read_excel("可用完整数据.xlsx")

# 特征选择：类型和门诊时间
X = data[["类型", "门诊时间"]]

# 将类型进行独热编码
X = pd.get_dummies(X, columns=["类型"], drop_first=True)

# 转换时间特征为时间戳
X["门诊时间"] = X["门诊时间"].apply(lambda x: datetime.timestamp(x))

# 目标变量：入院时间
y = data["入院时间"]

# 转换入院时间为时间戳
y = y.apply(lambda x: datetime.timestamp(x))

# 记录特征列的顺序
feature_order = X.columns.tolist()

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 创建随机森林回归模型
model = RandomForestRegressor(random_state=42)

# 训练模型
model.fit(X_train, y_train)

# 假设要预测的新数据
new_data = pd.DataFrame({
    "类型_白内障": [0],  # 注意：添加其他类型的特征列，并设置为0
    "类型_白内障(双眼)": [0],
    "类型_视网膜疾病": [1],  # 这里使用了 "视网膜疾病" 类型
    "类型_青光眼": [0],
    "门诊时间": [datetime(2023, 8, 20)]  # 需要预测的门诊时间
})

# 转换时间特征为时间戳
new_data["门诊时间"] = new_data["门诊时间"].apply(lambda x: datetime.timestamp(x))

# 重新排列特征列的顺序
new_data = new_data[feature_order]

# 进行预测
predicted_timestamp = model.predict(new_data)

# 将预测结果转换回时间格式
predicted_datetime = datetime.fromtimestamp(predicted_timestamp[0])

print("预测的入院时间:", predicted_datetime)
