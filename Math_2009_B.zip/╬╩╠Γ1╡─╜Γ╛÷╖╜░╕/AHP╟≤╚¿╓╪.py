import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# 设置中文字体
font = FontProperties(fname=r"C:\Windows\Fonts\SimSun.ttc", size=12)

# 假设有3个指标：等待时间、病床利用率、住院时间
indicators = ['病人等待时间', '平均病床利用率', '病床占用时间']

# 假设对每个指标的两两比较矩阵如下，1表示同等重要性，3表示A相对于B稍微重要，5表示A相对于B明显重要，7和9类似
comparison_matrix = np.array([
    [1, 3, 5],
    [1/3, 1, 3],
    [1/5, 1/3, 1]
])

# 计算每列的权重
column_sum = np.sum(comparison_matrix, axis=0)
column_weights = column_sum / np.sum(column_sum)

# 计算最终权重
final_weights = column_weights / np.sum(column_weights)

# 创建饼状图
plt.figure(figsize=(6, 6))
plt.pie(final_weights, labels=indicators, autopct='%1.1f%%', startangle=140, textprops={'fontproperties': font})
plt.title('指标权重饼状图', fontproperties=font)
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
plt.savefig('指标权重饼状图.png')
# 显示图表
plt.show()
