import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']  # 或者使用 ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

# 读取 Excel 数据
data = pd.read_excel('排序后的数据.xlsx')

# 提取数据列
x_values = data['入院时间']
y_values = data['病床利用率']

# 绘制折线图
plt.figure(figsize=(10, 6))
plt.plot(x_values, y_values, marker='o', linestyle='-', color='b')
plt.xlabel('时间')
plt.ylabel('床位利用率')
plt.title('床位利用率随时间变化趋势')
plt.grid(True)
plt.show()
