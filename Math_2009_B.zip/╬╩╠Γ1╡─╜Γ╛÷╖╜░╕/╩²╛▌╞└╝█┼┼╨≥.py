import pandas as pd

# 读取数据，假设数据已经是CSV格式
data = pd.read_excel("可用完整数据.xlsx")

# 假设评价指标公式为：评价指标 = a * 病人等待时间 + b * 病床利用率 + c * 病人住院时间
a = 0.103  # 替换为您的实际值
b = 0.291  # 替换为您的实际值
c = 0.605    # 替换为您的实际值

# 计算评价指标
data['评价指标'] = a * data['病人等待时间'] + b * data['病床利用率'] + c * data['病床占用时间']

# 按照评价指标进行排序
sorted_data = data.sort_values(by='评价指标', ascending=False)

# 打印排序后的数据
print(sorted_data)

df = pd.DataFrame(sorted_data)

df.to_excel('排序后的数据.xlsx', index=False)
