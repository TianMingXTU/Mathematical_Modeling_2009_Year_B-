import pandas as pd
import numpy as np

# 读取数据，假设数据已经是CSV格式
data = pd.read_excel('原数据.xlsx')

# 将时间列转换为日期时间格式（假设日期时间格式是"YYYY-MM-DD"）
date_columns = ['门诊时间', '入院时间', '出院时间', '第一次手术时间', '第二次手术时间']
for col in date_columns:
    data[col] = pd.to_datetime(data[col], errors='coerce', format="%Y-%m-%d")

# 计算病床占用时间
data['病床占用时间'] = (data['出院时间'] - data['入院时间']).dt.days

# 计算病人等待时间
data['病人等待时间'] = (data['入院时间'] - data['门诊时间']).dt.days

# 计算总的资源时间
total_bed_available_time = 79 * (pd.Timestamp("2008-09-11") - pd.Timestamp("2008-07-13")).days

# 计算病床利用率
data['病床利用率'] = data['病床占用时间'] / total_bed_available_time

# 保存结果到Excel表
data.to_excel("结果数据.xlsx", index=False)
