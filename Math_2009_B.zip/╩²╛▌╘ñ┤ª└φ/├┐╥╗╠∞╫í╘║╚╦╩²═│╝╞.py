import pandas as pd
from datetime import datetime, timedelta

# 读取Excel表格数据
data = pd.read_excel('可用完整数据.xlsx')

# 转换日期字符串为日期类型
data['入院时间'] = pd.to_datetime(data['入院时间'])
data['出院时间'] = pd.to_datetime(data['出院时间'])

# 设定统计的起始和结束日期
start_date = datetime(2008, 7, 13)
end_date = datetime(2008, 9, 11)

# 创建一个日期范围
date_range = pd.date_range(start_date, end_date, freq='D')

# 初始化一个字典来存储每一天的人数
daily_counts = {}

# 遍历日期范围
for date in date_range:
    # 统计在当前日期范围内入院但未出院的人数
    count = ((data['入院时间'] <= date) & (data['出院时间'] > date)).sum()
    daily_counts[date] = count / 79


# 将统计结果转换成DataFrame
result_df = pd.DataFrame(list(daily_counts.items()), columns=['日期', '病床利用率'])

# 保存结果到Excel文件
result_df.to_excel('病床利用率.xlsx', index=False)
# 打印每一天的统计结果
for date, count in daily_counts.items():
    print(f"{date.strftime('%Y-%m-%d')}: {count} ")
