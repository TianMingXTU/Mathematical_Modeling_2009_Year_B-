import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# 读取数据，假设数据已经是CSV格式
data = pd.read_excel("可用完整数据.xlsx")

font = FontProperties(fname=r"C:\Windows\Fonts\SimSun.ttc", size=12)

# 创建子图
fig, ax = plt.subplots(figsize=(10, 6))

# 绘制柱状图

ax.bar(data['类型'], data['病床利用率'])

# 添加标题和标签
ax.set_title('病床利用率柱状图', fontproperties=font)
ax.set_xlabel('病例类型', fontproperties=font)
ax.set_ylabel('病床利用率', fontproperties=font)

# 设置x轴标签旋转，以便显示中文
plt.xticks(rotation=45, fontproperties=font)

# 显示图表
plt.tight_layout()
plt.show()
