import pandas as pd

# 读取原始Excel表格数据
data = pd.read_excel('可用完整数据.xlsx')

# 读取时间和人数的Excel数据
time_and_count_data = pd.read_excel('病床利用率.xlsx')

# 将时间和人数的数据转换成字典
time_and_count_dict = dict(zip(time_and_count_data['日期'], time_and_count_data['病床利用率']))

# 计算每一行的入院时间和出院时间之间的天数，并计算平均人数
avg_counts = []
for index, row in data.iterrows():
    entry_date = row['入院时间']
    exit_date = row['出院时间']

    if pd.notnull(entry_date) and pd.notnull(exit_date):
        days_in_hospital = (exit_date - entry_date).days + 1
        avg_count = sum(time_and_count_dict.get(entry_date + pd.Timedelta(days=i), 0) for i in
                        range(days_in_hospital)) / days_in_hospital
        avg_counts.append(avg_count)
    else:
        avg_counts.append(None)

# 将平均人数添加到原始数据中
data['平均病床利用率'] = avg_counts

# 保存结果到原始Excel表格
data.to_excel('可用完整数据.xlsx', index=False)
