import pandas as pd
import numpy as np
from scipy.optimize import minimize
import matplotlib.pyplot as plt


plt.rcParams['font.sans-serif'] = ['SimHei']  # 或者使用 ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False
# 读取Excel数据
data = pd.read_excel('可用完整数据.xlsx')

# 初始化参数
max_beds = 79
patient_types = ['白内障', '白内障(双眼)', '视网膜疾病', '青光眼', '外伤']  # 病人类型
total_patients = len(data)
total_simulation_days = (max(data['出院时间']) - min(data['门诊时间'])).days + 1


# 定义目标函数，即平均逗留时间
def objective_function(allocation_ratios):
    allocated_beds = {patient_type: allocation_ratio * max_beds for patient_type, allocation_ratio in zip(patient_types, allocation_ratios)}

    total_stay_time = 0
    for _, row in data.iterrows():
        patient_type = row['类型']
        allocated_bed = allocated_beds[patient_type]
        total_stay_time += row['病人等待时间'] + row['病床占用时间'] * (1 / allocated_bed)

    return total_stay_time / total_patients


# 约束条件：比例之和为1
def constraint(allocation_ratios):
    return np.sum(allocation_ratios) - 1.0


initial_guess = np.ones(len(patient_types)) / len(patient_types)  # 初始猜测均匀分配

# 初始化存储目标函数值和分配比例的列表
objective_values = []
allocation_ratios_history = []


# 定义回调函数，在每一轮迭代后保存数据
def callback_function(xk):
    allocation_ratios_history.append(xk)
    current_objective_value = objective_function(xk)
    objective_values.append(current_objective_value)


# 定义优化算法的参数选项
options = {'maxiter': 100, 'disp': True, 'ftol': 1e-6}
# 使用优化算法最小化目标函数
result = minimize(objective_function, initial_guess, constraints={'type': 'eq', 'fun': constraint}, callback=callback_function, options=options)

# 输出最优病床分配比例
best_allocation_ratios = result.x
for patient_type, allocation_ratio in zip(patient_types, best_allocation_ratios):
    print("病人类型：{}，分配比例：{:.2f}".format(patient_type, allocation_ratio))

print("最佳平均逗留时间：{:.2f} 天".format(result.fun))

# 绘制扇形图显示病人类型和分配比例
plt.figure(figsize=(8, 8))
plt.pie(best_allocation_ratios, labels=patient_types, autopct='%.1f%%', startangle=140, shadow=True)
plt.title('病人类型分配比例')
plt.axis('equal')  # 保持纵横比一致，使扇形图为圆形
plt.savefig('病人类型分配比例.png')
plt.show()

# 可视化目标函数值随迭代次数的变化
plt.figure(figsize=(10, 6))
plt.plot(objective_values)
plt.xlabel('迭代次数')
plt.ylabel('目标函数值')
plt.title('目标函数值随迭代次数变换趋势图')
plt.grid()
plt.savefig('目标函数值随迭代次数变换趋势图.png')
plt.show()

# 可视化病床分配比例随迭代次数的变化
allocation_ratios_history = np.array(allocation_ratios_history)
plt.figure(figsize=(10, 6))
for i, patient_type in enumerate(patient_types):
    plt.plot(allocation_ratios_history[:, i], label=patient_type)

plt.xlabel('迭代次数')
plt.ylabel('分配比率')
plt.title('分配比率随迭代次数变换趋势图')
plt.legend()
plt.grid()
plt.savefig('分配比率随迭代次数变换趋势图.png')
plt.show()
